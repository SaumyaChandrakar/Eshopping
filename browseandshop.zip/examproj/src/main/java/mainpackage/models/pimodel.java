package mainpackage.models;


	public class pimodel {
		 String cid;

		public String getCid() {
			return cid;
		}

		public void setCid(String cid) {
			this.cid = cid;
		}

		public pimodel(String cid) {
			super();
			this.cid = cid;
		}

		public pimodel() {
			super();
			// TODO Auto-generated constructor stub
		}
		}


